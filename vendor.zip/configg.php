<?php

$dbhost = 'localhost';
$dbusername = 'root';
$dbpass = "";
$dbname = 'resultdb';
$connect = mysqli_connect($dbhost, $dbusername, $dbpass, $dbname);


?>