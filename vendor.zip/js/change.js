function change() {
    document.getElementById("see").innerHTML = 'Completed';
}